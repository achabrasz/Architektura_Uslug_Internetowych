package com.example.Sportsman_Module.Sportsman.Sport;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class Sport {
    String name;
}
