package com.example.aui.testConfig;

public class TestConfig {
}
