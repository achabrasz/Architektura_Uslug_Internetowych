package com.example.aui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;



@SpringBootTest
class AuiApplicationTests {

	@Test
	void contextLoads() {
	}

}
